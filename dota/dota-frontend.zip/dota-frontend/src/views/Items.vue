<template>
  <Items />
</template>

<script>
  import Items from '../components/Items'

  export default {
    components: {
      Items
    }
  }
</script>
