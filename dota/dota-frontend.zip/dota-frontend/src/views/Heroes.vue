<template>
  <Heroes />
</template>

<script>
  import Heroes from '../components/Heroes'

  export default {
    components: {
      Heroes
    }
  }
</script>
